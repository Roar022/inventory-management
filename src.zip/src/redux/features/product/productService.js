import axios from "axios";
import { toast } from "react-toastify";
export const BACKEND_URL = process.env.REACT_APP_BACKED_URL;


const API_URL = `${BACKEND_URL}/api/products`

// Create New Product
const createProduct = async (fromData) => {
  const response = await axios.post(API_URL, fromData);
  return response.data;
};

const productService = {
    createProduct
}

export default productService;
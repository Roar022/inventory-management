import React from "react";
// import loader image
import "./Loader.scss"
import  ReactDOM  from "react-dom";

const Loader = () => {
  return ReactDOM.createPortal(
    <div className="wrapper">
      <div className="loader">
        <img src={""} alt="LOading..." />
      </div>
    </div>,
    document.getElementById("loader")
  );
};
export const SpinnerImg = () => {
  return(
    <div className="--center-all">
      <img src={""} alt="Loading..." />
    </div>
  );
};

export default Loader;

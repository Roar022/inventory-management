import React, { useState } from "react";
import ProductForm from "../../components/productForm/ProductForm";
import { useSelector } from "react-redux";
import { selectIsLoading } from "../../redux/features/product/productSlice";

const initialState = {
  name: "",
  category: "",
  quantity: "",
  price: "",
};
const AddProduct = () => {
  const [product, setProduct] = React.useState(initialState);
  const [productImage, setPrductImage] = React.useState("");
  const [imagePreview, setImagePreview] = React.useState(null);
  const [description, setDescription] = React.useState("");

  const isLoading = useSelector(selectIsLoading);

  const { name, category, price, quantity } = product;

    const handleInputChange = (e) =>{
        const {name, value} = e.target
    }


  return (
    <div>
      <h3 className="--mt">Add New Product</h3>
      <ProductForm />
    </div>
  );
};

export default AddProduct;
